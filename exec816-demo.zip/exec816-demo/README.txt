Exec816 0.2 system distribution
==================================

Preferred FujiNet boot: mount exec816.atr writable in D1 and boot it.
The same ATR contains OF816, the kernel, commands, applications and WORK.
No D8 disk is required. Keep a backup: saved programs and settings modify it.
QED, when supplied, lives on a separate optional qed.atr, read-only in D2.

Use the included AltirraOS 65816 ROM, Atari 800XL PAL, 65C816 at 14.28 MHz,
shadow ROMs enabled, 64K base RAM plus 4032K high RAM. Disable SIO Patch,
D: burst I/O and fast boot. Use Generic + 57600 baud disk emulation.
Graphical builds require a VBXE FX core at $D600 with private 512K VRAM
and an ST mouse on joystick port 2.

Boot transport disables internal BASIC and reopens the pinned ROM's text
screen above Exec's Task pools when necessary. Holding OPTION to keep BASIC
off is unnecessary once the disk reader starts. Arbitrary external cartridges
cannot be disabled generically; remove them unless booting the supplied
Atarimax image. That loader switches its own cartridge off before Exec entry.

All three launch choices use the same writable exec816.atr and WORK directory:
  ATR: mount it in D1 and cold-boot (preferred on FujiNet).
  XEX: load Exec-of816.xex with exec816.atr still mounted in D1.
  Cart: cold-boot the supplied Atarimax CAR with exec816.atr in D1.
The local launch-altirra.command, launch-xex.command and launch-cart-new.command
select these routes and reuse the same private writable disk copy.

FujiNet virtual-XEX boot uses its D1 slot for the XEX transport. For that route,
put exec816.atr writable in D2, interrupt the OF816 countdown, then enter:
  decimal
  2 SYSTEM-DRIVE!
  EXEC816
The ATR contents are unchanged. If also using QED, put qed.atr in D3 and use
MOUNT QED: DRIVE 3 FORMAT SPARTA. Ordinary ATR/cart boots use D1 and QED in D2.

Leave the keyboard alone for OF816's five-second countdown, or press a key
to enter Forth and type EXEC816 when ready. Keep the disks attached in Forth.
SYS: and D1: name the same writable volume on the default route. C: contains
commands, S: startup scripts, and WORK: names SYS:WORK. RAM: is temporary.

Ported SpartaDOS X tools MD5, ARC and EDX, their manuals and ARC overlays are
installed in SYS:C. Command names work with or without .COM. Try:
  CD WORK:
  MD5 ABC.TXT
  MD5 /C CHECK.MD5
  ARC
  ARC L SAMPLE.ARC
  EDX EDIT.TXT
EDX: Ctrl-S saves; Return confirms the name; Escape exits. EDX bell and live
resize are unsupported. The supplied MD5/ARC fixtures and editor text are in
WORK. Only the pinned ported binaries are supported; see the utility notice.

For the optional QED disk in D2:
  MOUNT QED: DRIVE 2 FORMAT SPARTA
  RUN QED:QED.APP WORK:SAMPLE.TXT
Save documents in WORK:. QED is not required for boot.

WORK files and desktop preferences survive cold boot. Final EXIT restores the
OS display; cold-reset to start again. BOOT.LDR and EXEC816.XEX are protected.
When updating, keep your old writable ATR and copy its WORK files into the new
image. Package refreshes do not migrate user files automatically.

Boot loading negotiates 57600 baud with FujiNet after the small standard-speed
reader. Interactive Forth gets standard-speed ROM I/O; EXEC816 resumes fast
loading. Keep FujiNet's HSIO index at 8 for native disk access. A failed transfer
parks with an error and requires reset. --boot-sio standard selects a slower
boot comparison/recovery reader; it does not change native storage's profile.
Development checks and physical hardware qualification are separate.

FastBasic workbench
-------------------

From Shell, type RUN C:BASIC.APP. The twelve-Task layout allows a second shell
beside the workbench and its interpreter Task. Output windows and AES
clients have separate limits; close extra applications when those are full.

Type PRINT 1.25*2.0 and press Control+Return: output should contain 2.5.
Run interprets the unsaved buffer without source, COM or diagnostic scratch files.
Program > Integer mode selects FBI for Run; floating point (FB) is the default.
Control+Shift+Return checks with FBC/FBCI without running. Parse errors select the source
byte and reveal folded lines. Successful Run returns to the editor position.

Select FastBasic output to enter INPUT/GET/KEY; select FastBasic for shortcuts.
Control+K, Program > Stop or closing output cancels the current run. Program > Output
reopens completed output. Quit waits for the run before Save/Discard/Cancel.
Run keeps the interpreter Process and BASIC state between runs. Try
A=A+1:PRINT A twice: it prints 1, then 2. Program > Restart interpreter clears
BASIC state while keeping the source. Changing Integer mode also resets it.
Repeated DIM keeps arrays of the same type and size; Restart before changing
those declarations. An idle interpreter keeps its Task and parks its BASIC state,
allowing another guest command to run.
Source edits are frozen during a job; Save and Save As remain available.

From Shell, FB WORK:CALC.BAS and FBI WORK:HELLO.BAS run source directly.
FB WORK:DECIMAL.BAS demonstrates decimal INPUT; BREAK stops FB WORK:BUSY.BAS.
FB/FBI require one source path. Source input is limited to 32 KiB, and its
parser, bytecode and variables still share one 64 KiB guest bank.

Control+B builds a standalone release COM. Choose WORK: as its destination.
Build does not save the source. Close the editor, then run the COM from Shell.
If publication or cleanup reports recovery paths, keep those copies; File >
Recovery paths displays build paths in output. RAM: contents vanish on reboot.

This first workbench delivery includes editing, Check, Run, Stop and Build.
Source debugging and native graphics are pending. FBC/FBCI remain available
from the shell, including the EDX edit/compile/run workflow.
Scrolling and line splits/joins preserve existing rows and columns. Horizontal
scrolling and large edits can still pause; responsiveness work remains open.
Resident SDX and BASIC execution
-------------------------------

MD5, ARC and EDX are installed on SYS:C/. Their names work without .COM.
One SDX or BASIC guest can execute at a time. EDX keeps that ownership while
waiting for a key. A second guest reports error 202 (object in use).

An idle FastBasic interpreter releases execution ownership while keeping its
Process, variables, arrays, strings and open channels. MD5, ARC, EDX and
Check/Build can run between BASIC runs. A busy Run preserves BASIC state.
Restart interpreter explicitly clears that state. INPUT, PAUSE and a running
loop retain execution ownership until completion or Stop.

Very deeply nested BASIC syntax reports "too long". ARC compression reports
resource error 158 if its recursive tree walk reaches the stack limit; owned
archive cleanup then preserves the original archive.

SDX utility support: pinned MD5, ARC and EDX.
MD5, ARC, EDX, their manuals and ARC overlays are in SYS:C/.
Guest A: files use WORK:; ARC overlays use SYS:C/.
EDX accepts a filename or opens a blank document. Ctrl-S saves;
Return confirms the name; Escape exits. Bell and live resize
are unsupported. ARC without arguments prints its original help.
Command names accept the optional .COM suffix.

FastBasic integer and floating-point programming

FB, FBI, FBCI, FBC, EDX, MD5 and ARC are installed in SYS:C. Run source with:
  FB WORK:CALC.BAS
  FBI WORK:HELLO.BAS
FB includes floating point; FBI is integer-only. Each requires a source path.
No temporary COM is created. Standard input remains available to BASIC.
Source is limited to 32 KiB; parser, bytecode and heap share its guest bank.

For the existing standalone compiler workflow, enter:
  CD WORK:
  EDX HELLO.BAS
EDX: Ctrl-Z goes to end of line; Ctrl-S saves; Return confirms; Esc exits.
Then enter:
  FBCI HELLO.BAS HELLO.COM
  HELLO
The supplied example prints HELLO BASIC and 42. Use HELLO.COM explicitly
if you run it from a directory without that compiled file: C:HELLO is a
different native demonstration command. Bare FBCI prompts for both filenames.

For floating point, edit CALC.BAS, compile with FBC CALC.BAS CALC.COM, then
run CALC. It prints 3.75, 9 and 1. Floating variables use the % suffix.
FBC DECIMAL.BAS DECIMAL.COM demonstrates decimal INPUT. Bare FBC also prompts.

Try FBCI INPUT.BAS INPUT.COM, then INPUT. BREAK cancels execution, including
BUSY.BAS, a loop with no I/O. Redirection and native paths are supported.
The writable work disk is disposable; back it up before experimenting.

This target supports integers, strings, arrays, procedures and native file
I/O, with six-byte Atari floating point and math functions in FBC.
The optional BASIC.APP editor runs unsaved source. Source debugging, Atari
graphics/sound and external USR assembly calls are not provided. Recompile older
binaries for target $4705. KEY() returns a queued console character
(zero if none), rather than an Atari CH scan code. PEEK/POKE address private
guest memory; they do not access Atari hardware. This is a development demo.
See licenses/FASTBASIC-NOTICES.txt and the separate corresponding-source archive.

Licenses and third-party notices are in licenses/.
