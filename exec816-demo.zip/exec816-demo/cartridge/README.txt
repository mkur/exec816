Exec816 Atarimax boot images
===========================

These images contain the exact matching Exec-of816.xex from this package.
OF816 retains its five-second countdown. Mount a private writable copy of the
same exec816.atr in D1 before booting; it contains SYS and the WORK directory.
No separate D8 disk is required. Optional QED remains on qed.atr in D2.
Follow ../README.txt for the ROM, CPU, memory, VBXE and disk requirements.

Use an Atarimax Maxflash 8 Mbit (1 MiB) cartridge. Files:
  *-new.car  CAR type 75, bank 0 at power-on
  *-old.car  CAR type 42, bank 127 at power-on
  *.bin      Raw 1 MiB programming image, both power-on variants
The CAR headers select the emulator mapper. Program physical flash from BIN,
without the 16-byte CAR header. The 128 KiB model is too small.

Cold-boot the CAR instead of the ATR or XEX. The loader disables internal
BASIC, switches its cartridge off for every INITAD callback and RUNAD, and
reopens the pinned ROM screen above the high-RAM Task pools. Its RAM reader
retires at RUNAD before native Task initialization. Exec runs entirely in RAM.
Other cartridge mappers and physical accelerator/cartridge timing are outside
these development checks. Warm reset is not a cartridge reload; cold-reset or
power-cycle. The same persistent system ATR is used by ATR, XEX and cart boot.

SHA256SUMS in the package root covers every artifact. Build intermediates,
local launchers and reports are intentionally outside the ZIP.
